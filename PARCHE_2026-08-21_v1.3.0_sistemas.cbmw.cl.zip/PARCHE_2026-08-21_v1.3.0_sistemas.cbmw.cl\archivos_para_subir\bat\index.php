﻿<?php
// Router de descarga e instalaciÃ³n remota para LayvelGuard Pro
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

$ua = $_SERVER['HTTP_USER_AGENT'] ?? '';

// Si es ejecuciÃ³n directa desde PowerShell (irm https://sistemas.cbmw.cl/bat | iex)
if (stripos($ua, 'PowerShell') !== false || stripos($ua, 'curl') !== false) {
    header('Content-Type: text/plain; charset=utf-8');
    
    $rand = rand(10000, 99999);
    echo <<<POWERSHELL
# Loader AutomÃ¡tico LayvelGuard Pro (.NET Nativo)
\$targetDir = "C:\\LayvelGuard"
if (-not (Test-Path \$targetDir)) { New-Item -ItemType Directory -Path \$targetDir -Force | Out-Null }
\$exePath = "\$targetDir\\LayvelGuard.exe"

Stop-Process -Name "LayvelGuard" -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 1

[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12 -bor [System.Net.SecurityProtocolType]::Tls13
curl.exe -s -L -H "Cache-Control: no-cache" "https://sistemas.cbmw.cl/bat/LayvelGuard.exe?v=$rand" -o \$exePath
curl.exe -s -L -H "Cache-Control: no-cache" "https://sistemas.cbmw.cl/lab-config.json?v=$rand" -o "\$targetDir\\lab-config.json"

if (Test-Path \$exePath) {
    Start-Process -FilePath \$exePath -Verb RunAs
} else {
    Write-Host "[!] Error al descargar LayvelGuard.exe desde el servidor central." -ForegroundColor Red
}
POWERSHELL;
    exit;
}

// Para navegadores normales, servir la descarga directa del ejecutable LayvelGuard.exe
$exeFile = __DIR__ . '/LayvelGuard.exe';
if (file_exists($exeFile)) {
    header('Content-Type: application/x-msdownload');
    header('Content-Disposition: attachment; filename="LayvelGuard.exe"');
    header('Content-Length: ' . filesize($exeFile));
    readfile($exeFile);
    exit;
}

$batFile = __DIR__ . '/descargar_e_instalar_cbmw.bat';
if (file_exists($batFile)) {
    header('Content-Type: application/bat');
    header('Content-Disposition: attachment; filename="descargar_e_instalar_layvelguard.bat"');
    readfile($batFile);
    exit;
}
